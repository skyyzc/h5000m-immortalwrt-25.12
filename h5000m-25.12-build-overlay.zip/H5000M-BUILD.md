# Hiveton H5000M migration build

This tree targets the H5000M support merged into ImmortalWrt `openwrt-25.12`
after the 25.12.1 release images were produced.

The first image is deliberately an initramfs test image. Do not use a
sysupgrade image until Ethernet, eMMC visibility, Wi-Fi, USB modem, fan,
buttons and LEDs have been verified from RAM with a serial console attached.

The local `higoros` package contains the HigoROS frontend and its statically
linked AArch64 backend extracted from the currently running vendor firmware.
It is for migration testing on the owner's device and is not redistributable.

Build on Linux:

    ./scripts/feeds update -a
    ./scripts/feeds install -a
    cp h5000m-initramfs.config .config
    make defconfig
    make download -j8
    make -j$(nproc)

Expected test artifact:

    bin/targets/mediatek/filogic/*h5000m*initramfs*

Load that artifact only through the existing Yuzhii U-Boot failsafe/initramfs
function. Do not upload the sysupgrade artifact during the RAM-test phase.
